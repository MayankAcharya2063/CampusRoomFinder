# Member 2 — GUI Presentation Layer & Central Stage Routing Manager

## What's included
- `StageCoordinator.java` — the required central navigation manager. Singleton
  that switches scenes and hands each new controller the logged-in `User`
  (and a `Resource` where relevant), since `FXMLLoader` can't pass constructor
  arguments.
- `ResourceListController` + `resource-list-view.fxml` — landing page for
  Students/Staff. Lists resources, supports search filtering, "Book" button,
  role-based visibility (Admins get an extra "Admin Dashboard" shortcut).
- `BookingController` + `booking-view.fxml` — booking request form with input
  validation (reuses Member 3's `InputValidator`, catches Member 3's
  `InvalidBookingDurationException` / `ResourceUnavailableException`).
- `AdminDashboardController` + `admin-dashboard-view.fxml` — Admin landing
  page listing pending bookings with approve/reject actions, guarded by
  Member 3's `AuthorizationGuard.requireAdmin(...)`.
- `styles.css` — extends the existing login stylesheet with matching
  component classes (`.page-header`, `.secondary-button`, `.reject-button`,
  etc.) so all screens look consistent.

## Integration notes for the team
Two placeholder model classes are included so this module compiles and can
be demoed standalone before everyone's code is merged:

- `model/Resource.java` — until the real resource domain class exists.
- `model/Booking.java` — Member 5 owns the real `Booking.java`.

Both are clearly marked with a banner comment. **Delete them and repoint the
imports once the real versions are merged** — field names match what the GUI
needs, so it should be close to a drop-in swap.

Also stubbed locally (clearly marked with `TODO (integration)` comments,
safe to delete once the real service exists):
- Sample resource/booking data in `loadSampleResources()` /
  `loadSampleBookings()` → replace with Member 6's `ResourceManager<T>` /
  persisted booking records.
- `BookingController.createBooking(...)` → replace with a call to Member 5's
  `BookingService.createBooking(...)`.
- Approve/Reject button handlers in `AdminDashboardController` → replace the
  direct status mutation with Member 4's `ApprovalWorkflowService`.

## Hook-up needed in Member 1's `LoginController`
`LoginController.navigateToDashboard(...)` currently has commented-out TODOs
expecting this class. Replace the `switch` block's TODO comments with:

```java
switch (role) {
    case ADMIN:
        StageCoordinator.getInstance().showAdminDashboard(user, currentStage);
        break;
    case STAFF:
    case STUDENT:
        StageCoordinator.getInstance().showResourceList(user, currentStage);
        break;
    default:
        showErrorAlert("Navigation Error", "Unknown user role. Cannot load dashboard.");
}
```
