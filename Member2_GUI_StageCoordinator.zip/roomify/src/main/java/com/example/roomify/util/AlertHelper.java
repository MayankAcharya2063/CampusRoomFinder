package com.example.roomify.util;

import javafx.scene.control.Alert;

/**
 * Small shared alert helper used by Member 2's GUI controllers.
 * <p>
 * NOTE: Member 3 owns AlertFactory.java as part of the exceptions/validation
 * module. Once that lands, these calls can be swapped for
 * {@code AlertFactory.showError(...)} / {@code AlertFactory.showInfo(...)}
 * with no change to controller logic.
 */
public final class AlertHelper {

    private AlertHelper() {
    }

    public static void showError(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static void showInfo(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static boolean showConfirm(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        return alert.showAndWait().filter(b -> b == javafx.scene.control.ButtonType.OK).isPresent();
    }
}
