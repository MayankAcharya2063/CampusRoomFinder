package com.example.roomify.model;

import java.io.Serializable;

/**
 * ============================================================================
 *  TEMPORARY INTEGRATION PLACEHOLDER
 *  ----------------------------------------------------------------------
 *  This class is NOT part of Member 2's assigned deliverables. It exists
 *  only so ResourceListController / BookingController / AdminDashboardController
 *  can compile and be demoed before the real domain classes exist.
 *
 *  Once the real resource model lands (Member 6's generics/collections module
 *  or wherever the team decides Resource.java belongs), DELETE this file and
 *  update the imports in the controllers below. The field names here match
 *  what the GUI needs so the swap should be a drop-in replacement.
 * ============================================================================
 */
public class Resource implements Serializable {
    private static final long serialVersionUID = 1L;

    private String resourceId;
    private String name;
    private String type;      // e.g. "Study Room", "Lab", "Auditorium"
    private int capacity;
    private String status;    // e.g. "AVAILABLE", "UNAVAILABLE", "MAINTENANCE"

    public Resource(String resourceId, String name, String type, int capacity, String status) {
        this.resourceId = resourceId;
        this.name = name;
        this.type = type;
        this.capacity = capacity;
        this.status = status;
    }

    public String getResourceId() { return resourceId; }
    public void setResourceId(String resourceId) { this.resourceId = resourceId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public int getCapacity() { return capacity; }
    public void setCapacity(int capacity) { this.capacity = capacity; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    @Override
    public String toString() {
        return name + " (" + type + ", capacity " + capacity + ")";
    }
}
