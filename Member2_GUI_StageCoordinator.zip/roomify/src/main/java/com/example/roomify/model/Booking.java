package com.example.roomify.model;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * ============================================================================
 *  TEMPORARY INTEGRATION PLACEHOLDER
 *  ----------------------------------------------------------------------
 *  Not one of Member 2's deliverables. Booking.java is officially owned by
 *  Member 5 (Core Booking Business Logic). This minimal version exists only
 *  so the GUI layer (BookingController, AdminDashboardController) can be
 *  built and demoed independently.
 *
 *  DELETE this file once Member 5's real Booking.java is merged, and point
 *  the imports at their version instead. Field names match what the GUI
 *  displays/edits, so the swap should need little to no controller changes.
 * ============================================================================
 */
public class Booking implements Serializable {
    private static final long serialVersionUID = 1L;

    private String bookingId;
    private String resourceId;
    private String resourceName;
    private String requesterName;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private String purpose;
    private String status; // "PENDING", "APPROVED", "REJECTED", "CANCELLED"

    public Booking(String bookingId, String resourceId, String resourceName, String requesterName,
                   LocalDateTime startTime, LocalDateTime endTime, String purpose, String status) {
        this.bookingId = bookingId;
        this.resourceId = resourceId;
        this.resourceName = resourceName;
        this.requesterName = requesterName;
        this.startTime = startTime;
        this.endTime = endTime;
        this.purpose = purpose;
        this.status = status;
    }

    public String getBookingId() { return bookingId; }
    public String getResourceId() { return resourceId; }
    public String getResourceName() { return resourceName; }
    public String getRequesterName() { return requesterName; }
    public LocalDateTime getStartTime() { return startTime; }
    public LocalDateTime getEndTime() { return endTime; }
    public String getPurpose() { return purpose; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}
